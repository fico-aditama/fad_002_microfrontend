<script setup lang="ts">
import WeatherWidget from './components/WeatherWidget.vue';
</script>

<template>
  <div class="app">
    <WeatherWidget />
  </div>
</template>

<style scoped>
.app {
  font-family: 'Arial', sans-serif;
}
</style>
